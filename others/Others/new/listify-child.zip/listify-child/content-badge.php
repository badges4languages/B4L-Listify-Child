<?php
/**
 * The template for displaying standard blog content.
 *
 * @package Listify
 */

 //echo '"style = min-height: 244px;"' .
?>

<?php if ( listify_has_integration( 'woocommerce' ) ) : ?>
	<?php wc_print_notices(); ?>
<?php endif; ?>

<?php
if ( '' == get_the_content() ) {
	return;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if ( ! is_singular( 'page' ) ) : ?>
	<header <?php echo apply_filters( 'listify_cover', 'entry-header entry-cover' ); ?>>

	</header><!-- .entry-header -->
	<?php endif; ?>

	<!-- showing the badge title under the picture -->
	<h1><a href="<?php the_permalink(); ?>" rel="bookmark"><?php  the_title(); ?></a></h1>
	<div class="content-box-inner">



		<?php if ( is_singular() ) : ?>
			<div class="entry-content">
				<?php the_content(); ?>
			</div>
		<?php else : ?>
			<div class="entry-summary">
				<?php the_excerpt(); ?>
			</div><!-- .entry-summary -->
		<?php endif; ?>

		<?php wp_link_pages(); ?>

	</div>
</article><!-- #post-## -->
